<?php
$telegram_id = "6420859830";
$id_bot = "7444557595:AAE8Sb470Ht69AJ8K3rx3bYBSB5zwEkToko";
?>
